from tavrida import client
from tavrida import config
from tavrida import discovery
from tavrida import entry_point

creds = config.Credentials("guest", "guest")
conf = config.ConnectionConfig("localhost", credentials=creds)

# You should always provide source !!!
source = entry_point.Source("client", "method")


cli = client.RPCClient(config=conf, service="test_hello",
                       exchange="test_exchange", source=source,
                       headers={"aaa": "bbb"})
import time
start_time = time.time()

while time.time() - start_time <= 60.1:
    cli.hello(param=123).cast(correlation_id="123-456")
