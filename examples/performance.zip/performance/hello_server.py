import logging

logging.basicConfig(level=logging.INFO)

from tavrida import config
from tavrida import discovery
from tavrida import dispatcher
from tavrida import server
from tavrida import service

import time
import sys


@dispatcher.rpc_service("test_hello")
class HelloController(service.ServiceController):

    started = False
    start_time = None
    counter_sent = 0
    counter_received = 0

    @dispatcher.rpc_method(service="test_hello", method="hello")
    def hello(self, request, proxy, param):
        if not self.started:
            self.started = True
            self.start_time = time.time()

        if time.time() - self.start_time >= 60:
            print "Stop"
            print "Time: %d" % (time.time() - self.start_time)
            print "Sent: %d" % self.counter_sent
            print "Received: %d" % self.counter_received
            sys.exit()
        self.counter_sent += 1
        proxy.test_world.world(param="proxy call - 1").call()

    @dispatcher.rpc_response_method(service="test_world", method="world")
    def world_resp(self, response, proxy, param):
        self.counter_received += 1


disc = discovery.LocalDiscovery()

# FOR RPC
# -------
# register remote service's exchanges to send there requests (RPC calls)
disc.register_remote_service("test_world", "test_world_exchange")

# FOR PUBLICATIONS
# ----------------
# register service's notification exchange to publish notifications
# Service 'test_hello' publishes notifications to it's exchange
# 'test_notification_exchange'
disc.register_local_publisher("test_hello", "test_notification_exchange")

# FOR RPC AND SUBSCRIBE
# ---------------------
# start server on given queue and exchange
# The given queue will be used to obtain messages from other services (rpc
# and publishers).
# The given exchange will be used by other services to send there it's
# requests, responses, errors.

creds = config.Credentials("guest", "guest")
conf = config.ConnectionConfig("localhost", credentials=creds,
                               async_engine=False)

srv = server.Server(conf,
                    queue_name="test_service", exchange_name="test_exchange",
                    service_list=[HelloController])
srv.run()
